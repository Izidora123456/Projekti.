/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package domen;

import java.io.Serializable;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 *
 * @author izido
 */
public class Profesor implements Serializable, OpstiDomenskiObjekat{
    private int profesorID;
    private String imePrezime;
    private String titula;
    private Date datumRodjenja;

    public Profesor() {
    }

    public Profesor(int profesorID, String imePrezime, String titula, Date datumRodjenja) {
        this.profesorID = profesorID;
        this.imePrezime = imePrezime;
        this.titula = titula;
        this.datumRodjenja = datumRodjenja;
    }  

    public int getProfesorID() {
        return profesorID;
    }

    public void setProfesorID(int profesorID) {
        this.profesorID = profesorID;
    }

    public String getImePrezime() {
        return imePrezime;
    }

    public void setImePrezime(String imePrezime) {
        this.imePrezime = imePrezime;
    }

    public String getTitula() {
        return titula;
    }

    public void setTitula(String titula) {
        this.titula = titula;
    }

    public Date getDatumRodjenja() {
        return datumRodjenja;
    }

    public void setDatumRodjenja(Date datumRodjenja) {
        this.datumRodjenja = datumRodjenja;
    }

    @Override
    public String toString() {
        return imePrezime;
    }

    @Override
    public String vratiNazivTabele() {
        return "profesor";
   }

    @Override
    public String vratiNaziveAtributa() {
        return " (imePrezime, titula, datumRodjenja) ";
     }

    @Override
    public String vratiVrednostZaInsert() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        return " '" + imePrezime + "','" + titula + "','" + sdf.format(datumRodjenja) + "'";
     }

    @Override
    public String vratiAtributeIzmena() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        return " profesorID ='" + profesorID + "', imePrezime='" + imePrezime + "', titula ='" + titula + "', datumRodjenja ='" + sdf.format(datumRodjenja) + "'";
    }

    @Override
    public String vratiUslovIzmene() {
        return " profesorID ='" + profesorID + "'";
    }

    @Override
    public String vratiUslovPretrage() {
        return "";
     }

    @Override
    public String vratiNazivKolone() {
        return "";
     }

    @Override
    public List<OpstiDomenskiObjekat> napuni(ResultSet rs) throws Exception {
       List<OpstiDomenskiObjekat> listaProfesora = new ArrayList<>();
        while (rs.next()) {
            Profesor p = new Profesor();
            p.setProfesorID(rs.getInt("profesorID"));
            p.setImePrezime(rs.getString("imePrezime"));
            p.setTitula(rs.getString("titula"));
            p.setDatumRodjenja(rs.getDate("datumRodjenja"));
            
            listaProfesora.add(p);
        }
        return listaProfesora;
     }

   

    @Override
    public OpstiDomenskiObjekat napraviPrazan() {
        return new Profesor(0, "", "", new Date());
    }
    
    
}
