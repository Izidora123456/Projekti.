/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package logika;

import domen.OpstiDomenskiObjekat;
import domen.Profesor;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import javax.swing.JComboBox;
import javax.swing.JTextField;
import java.util.Date;
import java.util.List;
import javax.swing.JOptionPane;
import komunikacija.Komunikacija;

/**
 *
 * @author izido
 */
public class ProfesorKontroler {

    public static Profesor unesiProfesora(JTextField txtImePrezime, JComboBox<String> cbTitula, JTextField txtDatumRodjenja) throws Exception {
        if (txtImePrezime.getText().isEmpty() || txtDatumRodjenja.getText().isEmpty()) {
            throw new Exception("Sva polja moraju biti pounjena!");
        }
        if (cbTitula.getSelectedItem().toString() == "*") {
            throw new Exception("Titula nije izabrana!");
        }
        String imePrezime = txtImePrezime.getText().trim();
        String titula = cbTitula.getSelectedItem().toString();
        String datumRodj = txtDatumRodjenja.getText().trim();

        SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy");
        Date datumRodjenja = new Date();
        datumRodjenja = sdf.parse(datumRodj);

        Profesor p = new Profesor(-1, imePrezime, titula, datumRodjenja);
        return p;
    }

    public static Profesor izmeniProfesora(JTextField txtProfesorID, JTextField txtImePrezime, JComboBox<String> cbTitula, JTextField txtDatumRodjenja) throws Exception {
        if (txtProfesorID.getText().isEmpty() || txtImePrezime.getText().isEmpty() || txtDatumRodjenja.getText().isEmpty()) {
            throw new Exception("Sva polja moraju da budu popunjena!");
        }

        if (cbTitula.getSelectedItem().toString() == "*") {
            throw new Exception("Titula nije izabrana!");
        }
        int idProfesora = Integer.parseInt(txtProfesorID.getText().trim());

        String imePrezime = txtImePrezime.getText().trim();
        String titula = cbTitula.getSelectedItem().toString();
        String datumRodj = txtDatumRodjenja.getText().trim();

        SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy");
        Date datumRodjenja = new Date();
        datumRodjenja = sdf.parse(datumRodj);

        Profesor p = new Profesor(idProfesora, imePrezime, titula, datumRodjenja);
        return p;
    }

    public static void popuniCBImePrezime(JComboBox cbImePrezime) {
        try {
            List<OpstiDomenskiObjekat> lista = Komunikacija.getInstanca().vratiProfesore();
            for (OpstiDomenskiObjekat opstiDomenskiObjekat : lista) {
                Profesor p = (Profesor) opstiDomenskiObjekat;
                cbImePrezime.addItem(p);
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Nije uspelo ucitavanje.", "Nije uspelo ucitavanje.", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void popuniCBTitula(JComboBox<String> cbTitula) {
        try {
            List<String> pomocnaLista = new ArrayList<>();
            List<OpstiDomenskiObjekat> lista = Komunikacija.getInstanca().vratiProfesore();
            for (OpstiDomenskiObjekat opstiDomenskiObjekat : lista) {
                Profesor p = (Profesor) opstiDomenskiObjekat;
                if (!pomocnaLista.contains(p.getTitula())) {
                    pomocnaLista.add(p.getTitula());
                    cbTitula.addItem(p.getTitula());
                }
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Nije uspelo ucitavanje.", "Nije uspelo ucitavanje.", JOptionPane.ERROR_MESSAGE);
        }
    }

}
