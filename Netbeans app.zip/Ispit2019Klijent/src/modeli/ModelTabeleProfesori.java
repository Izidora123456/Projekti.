/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modeli;

import domen.OpstiDomenskiObjekat;
import domen.Profesor;
import java.util.ArrayList;
import java.util.List;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author izido
 */
public class ModelTabeleProfesori extends AbstractTableModel {

    List<Profesor> lista= new ArrayList<>();

    public ModelTabeleProfesori() {
        lista = new ArrayList<>();
    }

    public ModelTabeleProfesori(List<OpstiDomenskiObjekat> list) {
        for (OpstiDomenskiObjekat opstiDomenskiObjekat : list) {
            Profesor p = (Profesor) opstiDomenskiObjekat;
            lista.add(p);
        }
    }

    @Override
    public int getRowCount() {
        return lista.size();
    }

    @Override
    public int getColumnCount() {
        return 4;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        Profesor p = lista.get(rowIndex);
        switch (columnIndex) {
            case 0:
                return p.getProfesorID();
            case 1:
                return p.getImePrezime();
            case 2:
                return p.getTitula();
            case 3:
                return p.getDatumRodjenja();
            default:
                return "Greska!";
        }
    }

    @Override
    public String getColumnName(int column) {
        switch (column) {
            case 0:
                return "Profesor ID";
            case 1:
                return "Ime i prezime";
            case 2:
                return "Titula";
            case 3:
                return "DatumRodjenja ";
            default:
                return "Greska!";
        }
    }

    public void osvezi() {
        fireTableDataChanged();
    }

    public Profesor dajIzabranogProfesora(int red) {
        return lista.get(red);
    }

    public List<Profesor> getLista() {
        return lista;
    }

    public void setLista(List<Profesor> lista) {
        this.lista = lista;
        fireTableDataChanged();
    }

}
