/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package domen;

import java.io.Serializable;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Date;

/**
 *
 * @author izido
 */
public class Angazovanje implements Serializable, OpstiDomenskiObjekat {

    private int angazovanjeID;
    private TipAngazovanja tipAngazovanja;
    private SkolskaGodina skolskaGodina;
    private Predmet predmet;
    private Profesor profesor;
    private Korisnik korisnik;
    private String datumKreiranja;

    public Angazovanje() {
    }

    public Angazovanje(int angazovanjeID, TipAngazovanja tipAngazovanja, Predmet predmet, Profesor profesor, Korisnik korisnik,SkolskaGodina skolskaGodina, String datumKreiranja) {
        this.angazovanjeID = angazovanjeID;
        this.tipAngazovanja = tipAngazovanja;
        this.predmet = predmet;
        this.profesor = profesor;
        this.korisnik = korisnik;
        this.skolskaGodina = skolskaGodina;
        this.datumKreiranja=datumKreiranja;
    }

    public Predmet getPredmet() {
        return predmet;
    }

    public void setPredmet(Predmet predmet) {
        this.predmet = predmet;
    }

    public int getAngazovanjeID() {
        return angazovanjeID;
    }

    public void setAngazovanjeID(int angazovanjeID) {
        this.angazovanjeID = angazovanjeID;
    }

    public TipAngazovanja getTipAngazovanja() {
        return tipAngazovanja;
    }

    public void setTipAngazovanja(TipAngazovanja tipAngazovanja) {
        this.tipAngazovanja = tipAngazovanja;
    }

    public Profesor getProfesor() {
        return profesor;
    }

    public void setProfesor(Profesor profesor) {
        this.profesor = profesor;
    }

    public void setKorisnik(Korisnik korisnik) {
        this.korisnik = korisnik;
    }

    public Korisnik getKorisnik() {
        return korisnik;
    }

    public SkolskaGodina getSkolskaGodina() {
        return skolskaGodina;
    }

    public void setSkolskaGodina(SkolskaGodina skolskaGodina) {
        this.skolskaGodina = skolskaGodina;
    }

    public String getDatumKreiranja() {
        return datumKreiranja;
    }

    public void setDatumKreiranja(String datumKreiranja) {
        this.datumKreiranja = datumKreiranja;
    }

    
    @Override
    public String vratiNazivTabele() {
        return "angazovanje";
    }

    @Override
    public String vratiNaziveAtributa() {
        return " (predmetID,profesorID,tipAngazovanjaID,korisnikID,skolskaGodinaID,datumKreiranja) ";
    }

    @Override
    public String vratiVrednostZaInsert() {
        return "'" + predmet.getPredmetID() + "','" + profesor.getProfesorID() + "','" + tipAngazovanja.getTipAngazovanjaID()
                + "','" + korisnik.getKorisnikID() +  "','" + skolskaGodina.getSkolskaGodinaID() +  "','" + datumKreiranja + "'";
    }

    @Override
    public String vratiAtributeIzmena() {
        return "angazovanjeID='" + angazovanjeID + "', predmetID='" + predmet.getPredmetID() + "', profesorID='" + profesor.getProfesorID()
                + "', tipAngazovanjaID='" + tipAngazovanja.getTipAngazovanjaID() + "', korisnikID='" 
                + korisnik.getKorisnikID() + "', datumKreiranja='" + datumKreiranja+ "'";
    }

    @Override
    public String vratiUslovIzmene() {
        return "angazovanjeID='" + angazovanjeID + "'";
    }

    @Override
    public String vratiUslovPretrage() {
        return "";
    }

    @Override
    public String vratiNazivKolone() {
        return "";
    }

    @Override
    public List<OpstiDomenskiObjekat> napuni(ResultSet rs) throws Exception {
        List<OpstiDomenskiObjekat> listaAngazovanja = new ArrayList<>();
        while (rs.next()) {
            Angazovanje a = new Angazovanje();
            a.setAngazovanjeID(rs.getInt("angazovanjeID"));

            TipAngazovanja ta = new TipAngazovanja();
            ta.setTipAngazovanjaID(rs.getInt("tipAngazovanjaID"));

            Predmet p = new Predmet();
            p.setPredmetID(rs.getInt("predmetID"));

            Profesor pr = new Profesor();
            pr.setProfesorID(rs.getInt("profesorID"));

            Korisnik k = new Korisnik();
            k.setKorisnikID(rs.getInt("korisnikID"));
            
            SkolskaGodina sk = new SkolskaGodina();
            sk.setSkolskaGodinaID(rs.getInt("skolskaGodinaID"));

            a.setDatumKreiranja(rs.getString("datumKreiranja"));
            
            a.setTipAngazovanja(ta);
            a.setPredmet(p);
            a.setProfesor(pr);
            a.setKorisnik(k);
            a.setSkolskaGodina(sk);
            listaAngazovanja.add(a);
        }
        return listaAngazovanja;
    }

    @Override
    public OpstiDomenskiObjekat napraviPrazan() {
        TipAngazovanja ta = (TipAngazovanja) (new TipAngazovanja().napraviPrazan());
        Predmet p = (Predmet) (new Predmet()).napraviPrazan();
        Profesor pr = (Profesor) (new Profesor()).napraviPrazan();
        Korisnik k = (Korisnik) (new Korisnik()).napraviPrazan();
        SkolskaGodina sk = (SkolskaGodina) (new SkolskaGodina()).napraviPrazan();
        return new Angazovanje(0, ta, p, pr, k, sk, "");

    }

}
