/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package logika;

import domen.Angazovanje;
import domen.Korisnik;
import domen.Predmet;
import domen.Profesor;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import komunikacija.Komunikacija;

/**
 *
 * @author izido
 */
public class Kontroler {

    private static Kontroler instance = null;
    private Korisnik ulogovaniKorisnik;
    private List <Profesor> profesori;
    private List <Predmet> predmeti;
    private List <Angazovanje> angazovanja;
    

    private Kontroler() {
        
    }

    public static Kontroler getInstance() {
        if (instance == null) {
            instance = new Kontroler();
        }
        return instance;
    }

    public Korisnik getUlogovaniKorisnik() {
        return ulogovaniKorisnik;
    }

    public List <Profesor> getProfesori() {
        return profesori;
    }

    public List <Predmet> getPredmeti() {
        return predmeti;
    }

    public List <Angazovanje> getAngazovanja() {
        return angazovanja;
    }

    public void setUlogovaniKorisnik(Korisnik ulogovaniKorisnik) {
        this.ulogovaniKorisnik = ulogovaniKorisnik;
    }

    public void setProfesori(List <Profesor> profesori) {
        this.profesori = profesori;
    }

    public void setPredmeti(List <Predmet> predmeti) {
        this.predmeti = predmeti;
    }

    public void setAngazovanja(List <Angazovanje> angazovanja) {
        this.angazovanja = angazovanja;
    }

    public void setUlogovaniAgent(Korisnik k) {
        ulogovaniKorisnik = k;
    }

        

}
