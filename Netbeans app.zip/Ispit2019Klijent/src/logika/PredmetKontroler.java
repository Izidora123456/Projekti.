/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package logika;

import domen.OpstiDomenskiObjekat;
import domen.Predmet;
import domen.Profesor;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JTextPane;
import komunikacija.Komunikacija;

/**
 *
 * @author izido
 */
public class PredmetKontroler {
    
    public static void popuniGlavneProfesoreNaPredmetima(JComboBox<String> cbImePrezime) {
        try {
            List<OpstiDomenskiObjekat> lista = Komunikacija.getInstanca().vratiGlavneProfesoreNaPredmetima();
            for (OpstiDomenskiObjekat opstiDomenskiObjekat : lista) {
                Predmet p = (Predmet) opstiDomenskiObjekat;
                cbImePrezime.addItem(p.getGlavniProfesorNaPredmetu().getImePrezime());
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Nije uspelo ucitavanje.", "Nije uspelo ucitavanje.", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static Predmet unesiPredmet(JTextField txtNazivPredmeta, String semestar, Profesor glavniProfesor, JTextPane txtOpis) throws Exception {
        if (txtNazivPredmeta.getText().isEmpty()  || txtOpis.getText().isEmpty()) {
            throw new Exception("Sva polja moraju biti pounjena!");
        }
        if(semestar== "*") {
            throw new Exception("Semestar nije izabran!");
        }
        if(glavniProfesor== null) {
            throw new Exception("Profesor nije izabran!");
        }
        String nazivPredmeta = txtNazivPredmeta.getText().trim();
        String opis = txtOpis.getText().trim();
        int sem = Integer.parseInt(semestar);


        Predmet p = new Predmet(-1, nazivPredmeta, opis, sem, glavniProfesor);
        return p;
    }

    public static void popuniCBNazivPredmeta(JComboBox cbNazivPredmeta)   {
        try {
            List<OpstiDomenskiObjekat> lista = Komunikacija.getInstanca().vratiPredmete();
            for (OpstiDomenskiObjekat opstiDomenskiObjekat : lista) {
                Predmet p = (Predmet) opstiDomenskiObjekat;
                cbNazivPredmeta.addItem(p);
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Nije uspelo ucitavanje.", "Nije uspelo ucitavanje.", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void popuniCBGlavneProfesorePredmeta(JComboBox cbGlavniProfesorNaPredmetu) {
      try {
            List<OpstiDomenskiObjekat> lista = Komunikacija.getInstanca().vratiPredmete();
            for (OpstiDomenskiObjekat opstiDomenskiObjekat : lista) {
                Predmet p = (Predmet) opstiDomenskiObjekat;
                cbGlavniProfesorNaPredmetu.addItem(p.getGlavniProfesorNaPredmetu());
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Nije uspelo ucitavanje.", "Nije uspelo ucitavanje.", JOptionPane.ERROR_MESSAGE);
        }
    
    }

    
    
}
