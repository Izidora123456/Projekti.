-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 28, 2020 at 01:52 PM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.2.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ispit2019`
--

-- --------------------------------------------------------

--
-- Table structure for table `angazovanje`
--

CREATE TABLE `angazovanje` (
  `angazovanjeID` int(11) NOT NULL,
  `predmetID` int(11) NOT NULL,
  `profesorID` int(11) NOT NULL,
  `tipAngazovanjaID` int(11) NOT NULL,
  `korisnikID` int(11) DEFAULT NULL,
  `skolskaGodinaID` int(11) DEFAULT NULL,
  `datumKreiranja` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `angazovanje`
--

INSERT INTO `angazovanje` (`angazovanjeID`, `predmetID`, `profesorID`, `tipAngazovanjaID`, `korisnikID`, `skolskaGodinaID`, `datumKreiranja`) VALUES
(5, 1, 1, 2, 1, 1, '2019-11-16'),
(6, 3, 2, 1, 1, 1, '2019-11-16'),
(7, 4, 3, 1, 1, 1, '2019-11-16'),
(11, 1, 11, 1, 1, 1, '2019-11-19'),
(12, 1, 1, 1, 1, 1, '2019-11-21'),
(13, 1, 1, 1, 1, 1, '2019-11-21'),
(14, 2, 1, 1, 1, 1, '2019-11-21'),
(15, 1, 1, 1, 1, 1, '2019-11-21'),
(16, 4, 5, 2, 1, 1, '2019-11-30'),
(17, 9, 12, 1, 1, 1, '2019-11-30'),
(18, 1, 1, 2, 1, 1, '2019-11-30'),
(19, 1, 1, 2, 1, 1, '2019-11-30'),
(20, 1, 1, 2, 1, 1, '2019-11-30'),
(21, 12, 13, 3, 1, 4, '2019-12-02');

-- --------------------------------------------------------

--
-- Table structure for table `korisnik`
--

CREATE TABLE `korisnik` (
  `korisnikID` int(11) NOT NULL,
  `ime` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `prezime` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `username` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `korisnik`
--

INSERT INTO `korisnik` (`korisnikID`, `ime`, `prezime`, `username`, `password`) VALUES
(1, 'izidora', 'mazibrada', 'izidora', '123456');

-- --------------------------------------------------------

--
-- Table structure for table `predmet`
--

CREATE TABLE `predmet` (
  `predmetID` int(11) NOT NULL,
  `nazivPredmeta` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `opis` varchar(5000) COLLATE utf8_unicode_ci NOT NULL,
  `semestar` int(11) NOT NULL,
  `glavniProfesorNaPredmetu` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `predmet`
--

INSERT INTO `predmet` (`predmetID`, `nazivPredmeta`, `opis`, `semestar`, `glavniProfesorNaPredmetu`) VALUES
(1, 'Projektovanje Softvera', 'Godina na kojoj se izvodi nastava: IV godina (VIII semestar)\r\nBroj ESPB bodova: 6 bodova\r\nUslovi:\r\nCilj: Sticanje znanja o osnovnim konceptima, strategijama i metodama projektovanja softvera. Upoznavanje sa postojećim arhitekturnim stilovima i okvirima. Razmatranje principa i tehnika projektovanja korisničkog interfejsa.  Usvajanje jedne od metoda projektovanja softvera u kojoj će biti korišćeni uzori projektovanja i softverske komponente. Pregled alata i tehnika koje se koriste u analizi i ocenjivanju kvaliteta softvera. Razmatranje notacija i alata kod projektovanja softvera. Upoznavanje sa postojećim implementacionim tehnologijama. Savladavanje jednog od objektnih programskih jezika (Java ili C#).\r\nNačin polaganja: Ispit se sastoji iz tri dela: a) pismeni ispit (izrada zadataka na računaru) b) odbrana seminarskog rada c) usmeni deo ispita\r\n\r\nNačin ocenjivanja:\r\nIspit se sastoji iz tri dela:\r\n1. Pismeni ispit (Izrada zadataka na računaru):\r\nStudent koji je položio pismeni deo ispita dobija od 50 do 100 poena (BrojPoenaPismeni).\r\nNapomena: Studenti mogu u tekućoj školskoj godini da budu ocenjivani za njihove aktivnosti u toku izvođenja laboratorijskih vežbi. Broj poena se dobija po sledećoj formuli:\r\nBrojPoenaPismeni  = Broj urađenih zadataka * 10 poena\r\nPoložen pismeni deo ispita važi dva ispitna roka.\r\n\r\n2. Odbrana seminarskog rada\r\nStudent koji je odbranio seminarski rad dobija od 50 do 100 poena (BrojPoenaSeminar).\r\nNapomena:  Seminarski rad može da se brani nakon položenog pismenog dela ispita\r\n\r\n3. Usmeni deo ispita\r\nStudent koji je položio usmeni deo ispita dobija od 50 do 100 poena (BrojPoenaUsmeni).\r\nNapomena: Usmeni deo ispita se može polagati tek nakon odbranjenog seminarskog rada.\r\n\r\nOcena se dobija na osnovu sledeće formule:\r\nOcena = (BrojPoenaPismeni * 0.4) + (BrojPoenaSeminar * 0.3) + (BrojePoenaUsmeni*0.3)', 7, 1),
(2, 'Softverski Paterni', 'Naziv predmeta: SOFTVERSKI PATERNI \r\n\r\nGodina na kojoj se izvodi nastava: IV godina (VII semestar)\r\nBroj ESPB bodova: 6 bodova\r\nUslovi:\r\nCilj: Shvatanje definicija i različitih oblika predstavljanja uzora (paterna). Mogućnost praktičnog korišćenja uzora u različitim fazama razvoja softvera. Upoznavanje sa postojećim matematičkim formalizmima za opisivanje uzora.\r\nNačin polaganja: Ispit se sastoji iz tri dela: a) pismeni ispit b) odbrana seminarskog rada (za ocenu 9 i 10) v) usmeni deo ispita', 7, 1),
(3, 'Ekonomija ', 'Studijski programi: Informacioni sistemi i tehnologije; Menadžment i organizacija\r\n\r\nVrsta i nivo studija: osnovne akademske studije\r\n\r\nNastavnici: Dragana P. Kragulj, Sandra J. Jednak\r\nAsistent: Parežanin D. Miloš\r\nStatus predmeta: Obavezan\r\n\r\nBroj ESPB: 6\r\n\r\nCilj predmeta\r\n\r\nSticanje osnovnih znanja iz ekonomije (uvod u ekonomsku analizu, mikroekonomiju i makroekonomiju) kroz teoriju, tehnike i primere iz prakse. Predmet predstavlja uvod i osnov za srodne predmete na višim godinama.\r\n\r\nIshod predmeta  \r\n\r\nUpoznavanje sa ekonomskom naukom; rasvetljavanje i savlađivanje osnovnih ekonomskih kategorija i ekonomskih zakona; povezivanje ekonomskih pojmova, kao apstrakntih kategorija, sa praktičnim ekonomskim životom; pravilna orijentacija u identifikovanju značajnih privrednih zbivanja u jednoj zemlji, ali i na svetskom planu; razvijanje ekonomske logike i razmišljanja o savremenim ekonomskim tokovima.', 1, 7),
(4, 'Internet Tehnologije', 'Teorijska nastava: Uvod, Referentni modeli i standardi u računarsim mrežama. Internet kao infrastruktura za prenos i isporuku informacija. Otkanjanje anomalija u aplikacionom sloju TCP/IP modela uvođenjem Internet tehnologija za poslove slojeva sesije i prezentacije. Virtuelne privatne mreže. Principi razvoja aplikacija u Internet okruženju. Primena HTTP protokola kao emulacije transportnog sloja. XML tehnologije za memorisanje, obradu i vizuelizaciju podataka prezentacionog sloja. JSON. Internet tehnologije za obezbeđivanje distribuiranosti, skalabilnosti i pouzdanosti u aplikacijama elektronskog poslovanja. Servisno orijentisana arhitektura. Principi projektovanja i razvoja distribuiranih sistema elektronskog poslovanja baziranih na servisno orijentisanoj arhitekturi. Procesno orijentisano modelovanje. Aplikacioni serveri. Cloud Computing. Semantički veb i vizuelizacija podataka na vebu. Internet of things. Uporedni pregled tehnologija za razvoj informacionih sistema u internet okruženju. microsoft .NET tehnologije. JAVA tehnologije, PHP. Zaključna razmatranja i pravci daljeg razvoja Internet tehnologija.\r\n\r\nPraktična nastava: Dizajniranje elemenata korisničkog interfejsa. HTML5. JavaScript i jQuery tehnologije. Skladištenje i prenos podataka u veb okruženju. XML tehnologije. JSON tehnologije. JQGrid. AJAX. Implementacija poslovne logike. Razvoj veb aplikacija. PHP. Objektno orpijentisani PHP. Implementacija sloja podataka. MySQL. PHP Razvoj aplikacija sa MVC arhitekturom. Servisno orijentisana arhitektura. Veb servisi. Vizuelizacija podataka na vebu.', 7, 4),
(5, 'Novi predmet', 'Opis novog predmeta', 2, 6),
(8, 'a', 'a', 1, 1),
(9, 'Menadzment ljudskih resursa', 'opis1', 4, 4),
(10, 'Programski jezici', 'opis2', 6, 1),
(11, 'Inteligentni sistemi', 'opis2', 8, 4),
(12, 'xxx', 'opis3xx', 1, 7);

-- --------------------------------------------------------

--
-- Table structure for table `profesor`
--

CREATE TABLE `profesor` (
  `profesorID` int(11) NOT NULL,
  `imePrezime` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `titula` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `datumRodjenja` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `profesor`
--

INSERT INTO `profesor` (`profesorID`, `imePrezime`, `titula`, `datumRodjenja`) VALUES
(1, 'Sinisa Vlajic', 'Redovni', '1967-10-15'),
(2, 'Petar Petrovic', 'Vanredni', '1978-05-06'),
(3, 'Milan Markovic', 'Asistent', '1988-02-19'),
(4, 'Marko Markovic', 'Redovni', '1981-05-06'),
(5, 'Stefan Stefanovic', 'Asistent', '1993-02-11'),
(6, 'Mirko Mirkovic', 'Vanredni', '1991-05-09'),
(7, 'Sandra Jednak', 'Redovni', '1984-12-22'),
(8, 'Milivoje Mikic', 'Vanredni', '1989-09-17'),
(9, 'Novi Profesor', 'Redovni', '2000-05-12'),
(10, 'Nikola Nikolic', 'Asistent', '1990-03-21'),
(11, 'Marko Stefanovic', 'Vanredni', '1986-11-20'),
(12, 'Stefan Stefanovic', 'Asistent', '1984-10-21'),
(13, 'a', 'Redovni', '1988-11-21'),
(14, 'Marko Petrovic', 'Redovni', '1981-01-04'),
(15, 'Marko Petrovic', 'Redovni', '1982-07-04'),
(16, 'Marko Petrovic', 'Redovni', '1984-07-05'),
(17, 'Marko Petrovic', 'Redovni', '1983-05-04'),
(18, 'Petar Petrovic', 'Asistent', '1989-08-07');

-- --------------------------------------------------------

--
-- Table structure for table `skolskagodina`
--

CREATE TABLE `skolskagodina` (
  `skolskaGodinaID` int(11) NOT NULL,
  `nazivSkolskeGodine` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `skolskagodina`
--

INSERT INTO `skolskagodina` (`skolskaGodinaID`, `nazivSkolskeGodine`) VALUES
(1, '2019/2020'),
(2, '2018/2019'),
(3, '2017/2018'),
(4, '2016/2017');

-- --------------------------------------------------------

--
-- Table structure for table `tipangazovanja`
--

CREATE TABLE `tipangazovanja` (
  `tipAngazovanjaID` int(11) NOT NULL,
  `nazivTipAngazovanja` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tipangazovanja`
--

INSERT INTO `tipangazovanja` (`tipAngazovanjaID`, `nazivTipAngazovanja`) VALUES
(1, 'Vezbe'),
(2, 'Predavanja'),
(3, 'Lab. vezbe');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `angazovanje`
--
ALTER TABLE `angazovanje`
  ADD PRIMARY KEY (`angazovanjeID`),
  ADD KEY `predmetID` (`predmetID`),
  ADD KEY `profesorID` (`profesorID`),
  ADD KEY `korinsnikID` (`korisnikID`),
  ADD KEY `tipAngazovanjaID` (`tipAngazovanjaID`),
  ADD KEY `skolskaGodinaID` (`skolskaGodinaID`);

--
-- Indexes for table `korisnik`
--
ALTER TABLE `korisnik`
  ADD PRIMARY KEY (`korisnikID`);

--
-- Indexes for table `predmet`
--
ALTER TABLE `predmet`
  ADD PRIMARY KEY (`predmetID`),
  ADD KEY `glavniProfesorNaPredmetu` (`glavniProfesorNaPredmetu`);

--
-- Indexes for table `profesor`
--
ALTER TABLE `profesor`
  ADD PRIMARY KEY (`profesorID`);

--
-- Indexes for table `skolskagodina`
--
ALTER TABLE `skolskagodina`
  ADD PRIMARY KEY (`skolskaGodinaID`);

--
-- Indexes for table `tipangazovanja`
--
ALTER TABLE `tipangazovanja`
  ADD PRIMARY KEY (`tipAngazovanjaID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `angazovanje`
--
ALTER TABLE `angazovanje`
  MODIFY `angazovanjeID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `korisnik`
--
ALTER TABLE `korisnik`
  MODIFY `korisnikID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `predmet`
--
ALTER TABLE `predmet`
  MODIFY `predmetID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `profesor`
--
ALTER TABLE `profesor`
  MODIFY `profesorID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `skolskagodina`
--
ALTER TABLE `skolskagodina`
  MODIFY `skolskaGodinaID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tipangazovanja`
--
ALTER TABLE `tipangazovanja`
  MODIFY `tipAngazovanjaID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `angazovanje`
--
ALTER TABLE `angazovanje`
  ADD CONSTRAINT `angazovanje_ibfk_1` FOREIGN KEY (`predmetID`) REFERENCES `predmet` (`predmetID`),
  ADD CONSTRAINT `angazovanje_ibfk_2` FOREIGN KEY (`profesorID`) REFERENCES `profesor` (`profesorID`),
  ADD CONSTRAINT `angazovanje_ibfk_3` FOREIGN KEY (`korisnikID`) REFERENCES `korisnik` (`korisnikID`),
  ADD CONSTRAINT `angazovanje_ibfk_4` FOREIGN KEY (`tipAngazovanjaID`) REFERENCES `tipangazovanja` (`tipAngazovanjaID`),
  ADD CONSTRAINT `angazovanje_ibfk_5` FOREIGN KEY (`skolskaGodinaID`) REFERENCES `skolskagodina` (`skolskaGodinaID`);

--
-- Constraints for table `predmet`
--
ALTER TABLE `predmet`
  ADD CONSTRAINT `predmet_ibfk_1` FOREIGN KEY (`glavniProfesorNaPredmetu`) REFERENCES `profesor` (`profesorID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
