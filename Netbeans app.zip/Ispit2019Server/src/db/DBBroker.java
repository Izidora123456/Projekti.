/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package db;

import domen.Angazovanje;
import domen.OpstiDomenskiObjekat;
import domen.Predmet;
import domen.Profesor;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author izido
 */
public class DBBroker {
    
    Connection konekcija;
    private static DBBroker instance = null;
    
    private DBBroker() {

    }

    public static DBBroker getInstance() {
        if (instance == null) {
            instance = new DBBroker();
        }
        return instance;
    }
    
    public void ucitajDriver(){
        try {
            Class.forName("com.mysql.jdbc.Driver");
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(DBBroker.class.getName()).log(Level.SEVERE, null, ex);
        }
   
    } 
    public void otvoriKonekciju(){
    String url="jdbc:mysql://localhost:3306/ispit2019";
    String user="root";
    String pass="";
        try {
            konekcija=DriverManager.getConnection(url,user,pass);
            konekcija.setAutoCommit(false);
        } catch (SQLException ex) {
            Logger.getLogger(DBBroker.class.getName()).log(Level.SEVERE, null, ex);
        }
    
    }
    public void zatvoriKonekciju(){
        try {
            konekcija.close();
        } catch (SQLException ex) {
            Logger.getLogger(DBBroker.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    public void commit(){
        try {
            konekcija.commit();
        } catch (SQLException ex) {
            Logger.getLogger(DBBroker.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    public void rollback(){
        try {
            konekcija.rollback();
        } catch (SQLException ex) {
            Logger.getLogger(DBBroker.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void sacuvaj(OpstiDomenskiObjekat odo) throws SQLException {
        String upit = "INSERT INTO " + odo.vratiNazivTabele() + " " + odo.vratiNaziveAtributa() + " VALUES (" + odo.vratiVrednostZaInsert() + ")";
        System.out.println(upit);
        Statement statement = konekcija.createStatement();
        statement.executeUpdate(upit);
        statement.close();
    }

    public void izmeni(OpstiDomenskiObjekat odo) throws SQLException, ClassNotFoundException {
        String upit = "UPDATE " + odo.vratiNazivTabele() + " SET " + odo.vratiAtributeIzmena() + " WHERE " + odo.vratiUslovIzmene();
        System.out.println(upit);
        Statement statement = konekcija.createStatement();
        statement.executeUpdate(upit);
        statement.close();
    }

    public void obrisi(OpstiDomenskiObjekat odo) throws Exception {
        String upit = "DELETE FROM " + odo.vratiNazivTabele() + " WHERE " + odo.vratiUslovIzmene();
        System.out.println(upit);
        Statement statement = konekcija.createStatement();
        statement.executeUpdate(upit);
        statement.close();
    }

    public List<OpstiDomenskiObjekat> vratiSve(OpstiDomenskiObjekat odo) throws Exception {
        List<OpstiDomenskiObjekat> lista = new ArrayList<>();

        String upit = "SELECT * FROM " + odo.vratiNazivTabele();
        System.out.println(upit);

        Statement statement = konekcija.createStatement();
        ResultSet rs = statement.executeQuery(upit);
        lista = odo.napuni(rs);
        statement.close();
        return lista;
    }

    public List<OpstiDomenskiObjekat> vratiSve(OpstiDomenskiObjekat odo, String uslov) throws Exception {
        List<OpstiDomenskiObjekat> lista = new ArrayList<>();
        //System.out.println("Uslov");
        String upit;
        if (uslov.equals("")) {
            upit = "SELECT * FROM " + odo.vratiNazivTabele();
        } else {
            upit = "SELECT * FROM " + odo.vratiNazivTabele() + " WHERE " + uslov;

        }
        System.out.println(upit);

        //System.out.println("KKK" + konekcija);
        Statement statement = konekcija.createStatement();
        ResultSet rs = statement.executeQuery(upit);
        lista = odo.napuni(rs);
        statement.close();
        return lista;
    }
    
   

}
