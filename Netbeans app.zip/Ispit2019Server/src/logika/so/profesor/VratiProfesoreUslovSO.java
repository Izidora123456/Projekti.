/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package logika.so.profesor;

import db.DBBroker;
import domen.OpstiDomenskiObjekat;
import domen.Profesor;
import java.util.ArrayList;
import java.util.List;
import logika.so.OpstaSO;

/**
 *
 * @author izido
 */
public class VratiProfesoreUslovSO extends OpstaSO {

    private String uslov;
    private List<OpstiDomenskiObjekat> lista = new ArrayList<>();

    public String getUslov() {
        return uslov;
    }

    public void setUslov(String uslov) {
        this.uslov = uslov;
    }

    public List<OpstiDomenskiObjekat> getLista() {
        return lista;
    }

    public void setLista(List<OpstiDomenskiObjekat> lista) {
        this.lista = lista;
    }
            
    @Override
    public void proveriPreduslov(Object obj) throws Exception {
        
    }

    @Override
    public void izvrsiKonkretnuOperaciju(Object obj) throws Exception {        
        lista = DBBroker.getInstance().vratiSve((Profesor)obj, uslov); 
    } 
    
}
