/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package komunikacija;

import domen.Angazovanje;
import domen.Korisnik;
import domen.OpstiDomenskiObjekat;
import domen.Predmet;
import domen.Profesor;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import transfer.TransferniObjekat;

/**
 *
 * @author izido
 */
public class Komunikacija {
    Socket socket;
    private ObjectOutputStream out;
    private ObjectInputStream in;
    private boolean prekid = false;
    
    private static Komunikacija instanca;

     public static Komunikacija getInstanca() throws Exception {
        if (instanca == null) {
            instanca = new Komunikacija();
        }
        return instanca;
    }

    public ObjectOutputStream getOut() {
        return out;
    }

    public void setOut(ObjectOutputStream out) {
        this.out = out;
    }

    public ObjectInputStream getIn() {
        return in;
    }

    public void setIn(ObjectInputStream in) {
        this.in = in;
    }

    public Komunikacija() throws IOException {

        Socket socket = new Socket("localhost", 9000);
        this.socket = socket;
        inicijalizujTokove();
    }

    public void inicijalizujTokove() throws IOException {
        System.out.println("Inicijalizacija tokova");
        out = new ObjectOutputStream(socket.getOutputStream());
        in = new ObjectInputStream(socket.getInputStream());
        System.out.println("Tokovi su inicijalizovani");

    }
    
    
    public Korisnik ulogujSe(Korisnik korisnik) throws Exception  {
       TransferniObjekat to = new TransferniObjekat(TransferniObjekat.ULOGUJ_SE, korisnik, null, null);
        out.writeObject(to);

        to = (TransferniObjekat) in.readObject();
        if (to.getIzuzetak() == null) {
            return (Korisnik) to.getPovratnaVrednost();
        } else {
            Exception e = to.getIzuzetak();
            throw e;
        }
    }
    
    public String unesiProfesora(Profesor profesor) throws Exception {
        TransferniObjekat to = new TransferniObjekat(TransferniObjekat.SACUVAJ_PROFESORA, profesor, null, null);
        out.writeObject(to);

        to = (TransferniObjekat) in.readObject();
        if (to.getIzuzetak() == null) {
            return (String) to.getPovratnaVrednost();
        } else {
            Exception e = to.getIzuzetak();
            throw e;
        }
    }
    
    public String izmeniProfesora(Profesor izmenjenProfesor) throws Exception {
        TransferniObjekat to = new TransferniObjekat(TransferniObjekat.IZMENI_PROFESORA, izmenjenProfesor, null, null);
        out.writeObject(to);

        to = (TransferniObjekat) in.readObject();
        if (to.getIzuzetak() == null) {
            return (String) to.getPovratnaVrednost();
        } else {
            Exception e = to.getIzuzetak();
            throw e;
        }
    }

    public List<OpstiDomenskiObjekat> vratiProfesore() throws Exception {
        TransferniObjekat to = new TransferniObjekat(TransferniObjekat.VRATI_SVE_PROFESORE, null, null, null);
        out.writeObject(to);

        to = (TransferniObjekat) in.readObject();
        if (to.getIzuzetak() == null) {
            return (List<OpstiDomenskiObjekat>) to.getPovratnaVrednost();
        } else {
            Exception e = to.getIzuzetak();
            throw e;
        }
    }

    public List<OpstiDomenskiObjekat> pretraziProfesore(Profesor p)  throws Exception {
        TransferniObjekat to = new TransferniObjekat(TransferniObjekat.VRATI_SVE_PROFESORE, p, null, null);
        out.writeObject(to);

        to = (TransferniObjekat) in.readObject();
        if (to.getIzuzetak() == null) {
            return (List<OpstiDomenskiObjekat>) to.getPovratnaVrednost();
        } else {
            Exception e = to.getIzuzetak();
            throw e;
        } 
    }

    public List<OpstiDomenskiObjekat> vratiGlavneProfesoreNaPredmetima() throws Exception {
        TransferniObjekat to = new TransferniObjekat(TransferniObjekat.VRATI_SVE_PROFESORE ,null, null, null);
        out.writeObject(to);

        to = (TransferniObjekat) in.readObject();
        if (to.getIzuzetak() == null) {
            return (List<OpstiDomenskiObjekat>) to.getPovratnaVrednost();
        } else {
            Exception e = to.getIzuzetak();
            throw e;
        }
    }

    public String unesiPredmet(Predmet predmet) throws Exception {
        TransferniObjekat to = new TransferniObjekat(TransferniObjekat.SACUVAJ_PREDMET, predmet, null, null);
        out.writeObject(to);

        to = (TransferniObjekat) in.readObject();
        if (to.getIzuzetak() == null) {
            return (String) to.getPovratnaVrednost();
        } else {
            Exception e = to.getIzuzetak();
            throw e;
        }
    }

    public List<OpstiDomenskiObjekat> vratiPredmete() throws Exception  {
        TransferniObjekat to = new TransferniObjekat(TransferniObjekat.VRATI_SVE_PREDMETE, null, null, null);
        out.writeObject(to);

        to = (TransferniObjekat) in.readObject();
        if (to.getIzuzetak() == null) {
            return (List<OpstiDomenskiObjekat>) to.getPovratnaVrednost();
        } else {
            Exception e = to.getIzuzetak();
            throw e;
        }
    }
    public List<OpstiDomenskiObjekat> pretraziPredmete(Predmet p) throws Exception  {
       TransferniObjekat to = new TransferniObjekat(TransferniObjekat.VRATI_SVE_PREDMETE, p, null, null);
        out.writeObject(to);

        to = (TransferniObjekat) in.readObject();
        if (to.getIzuzetak() == null) {
            return (List<OpstiDomenskiObjekat>) to.getPovratnaVrednost();
        } else {
            Exception e = to.getIzuzetak();
            throw e;
        } 
    }

    public String obrisiPredmet(Predmet p) throws Exception{
       TransferniObjekat to = new TransferniObjekat(TransferniObjekat.OBRISI_PREDMET, p, null, null);
        out.writeObject(to);

        to = (TransferniObjekat) in.readObject();
        if (to.getIzuzetak() == null) {
            return (String) to.getPovratnaVrednost();
        } else {
            Exception e = to.getIzuzetak();
            throw e;
        }
    }

    public List<OpstiDomenskiObjekat> vratiSkolskeGodine() throws Exception{
       TransferniObjekat to = new TransferniObjekat(TransferniObjekat.VRATI_SVE_SKOLSKE_GODINE, null, null, null);
        out.writeObject(to);

        to = (TransferniObjekat) in.readObject();
        if (to.getIzuzetak() == null) {
            return (List<OpstiDomenskiObjekat>) to.getPovratnaVrednost();
        } else {
            Exception e = to.getIzuzetak();
            throw e;
        }
    }

    public List<OpstiDomenskiObjekat> vratiTipAngazovanja() throws Exception{
     TransferniObjekat to = new TransferniObjekat(TransferniObjekat.VRATI_SVE_TIPOVE_ANGAZOVANJA, null, null, null);
        out.writeObject(to);

        to = (TransferniObjekat) in.readObject();
        if (to.getIzuzetak() == null) {
            return (List<OpstiDomenskiObjekat>) to.getPovratnaVrednost();
        } else {
            Exception e = to.getIzuzetak();
            throw e;
        }
    }
    public List<OpstiDomenskiObjekat> vratiAngazovanja() throws Exception  {
        TransferniObjekat to = new TransferniObjekat(TransferniObjekat.VRATI_ANGAZOVANJE, null, null, null);
        out.writeObject(to);

        to = (TransferniObjekat) in.readObject();
        if (to.getIzuzetak() == null) {
            return (List<OpstiDomenskiObjekat>) to.getPovratnaVrednost();
        } else {
            Exception e = to.getIzuzetak();
            throw e;
        }
    }
    public List<OpstiDomenskiObjekat> vratiAngazovanja(Angazovanje a) throws Exception {
        TransferniObjekat to = new TransferniObjekat(TransferniObjekat.VRATI_ANGAZOVANJE, a, null, null);
        out.writeObject(to);

        to = (TransferniObjekat) in.readObject();
        if (to.getIzuzetak() == null) {
            return (List<OpstiDomenskiObjekat>) to.getPovratnaVrednost();
        } else {
            Exception e = to.getIzuzetak();
            throw e;
        } 
    }

    public String unesiAngazovanje(Angazovanje a) throws Exception {
       TransferniObjekat to = new TransferniObjekat(TransferniObjekat.SACUVAJ_ANGAZOVANJE, a, null, null);
        out.writeObject(to);

        to = (TransferniObjekat) in.readObject();
        if (to.getIzuzetak() == null) {
            return (String) to.getPovratnaVrednost();
        } else {
            Exception e = to.getIzuzetak();
            throw e;
        }
    }

   


    




}
