/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package logika.so.profesor;

import domen.OpstiDomenskiObjekat;
import domen.Profesor;
import db.DBBroker;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import logika.so.OpstaSO;

/**
 *
 * @author izido
 */
public class VratiProfesoreSO extends OpstaSO {

    private List<OpstiDomenskiObjekat> lista = new ArrayList<>();

    public List<OpstiDomenskiObjekat> getLista() {
        return lista;
    }

    public void setLista(List<OpstiDomenskiObjekat> lista) {
        this.lista = lista;
    }

    @Override
    public void proveriPreduslov(Object obj) throws Exception {

    }

    @Override
    public void izvrsiKonkretnuOperaciju(Object obj) throws Exception {
        lista = DBBroker.getInstance().vratiSve((Profesor) obj);        
    }

}
